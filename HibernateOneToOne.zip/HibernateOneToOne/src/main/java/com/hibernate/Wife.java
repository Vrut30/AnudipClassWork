package com.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="wife_Details")
public class Wife{
	@Id
	private int WId;
	@Column (name="wife_name")
	private String WName;
	@OneToOne
	private Husband husband;

	public Wife() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wife(int wId, String wName, Husband husband) {
		super();
		WId = wId;
		WName = wName;
		this.husband = husband;
	}

	public int getWId() {
		return WId;
	}

	public void setWId(int wId) {
		WId = wId;
	}

	public String getWName() {
		return WName;
	}

	public void setWName(String wName) {
		WName = wName;
	}

	public Husband getHusband() {
		return husband;
	}

	public void setHusband(Husband husband) {
		this.husband = husband;
	}

	@Override
	public String toString() {
		return "Wife [WId=" + WId + ", WName=" + WName + ", husband=" + husband + "]";
	}
}
