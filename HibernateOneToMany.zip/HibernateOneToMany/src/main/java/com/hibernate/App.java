package com.hibernate;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.entity.Parent;
import com.hibernate.entity.Child;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration();
    	cfg.configure("hibernate.cfg.xml");
    	
    	SessionFactory sessionFactory=cfg.buildSessionFactory();
    	
    	Session session=sessionFactory.openSession();
    	
    	Transaction tr=session.beginTransaction();
    	
    	Parent pt=new Parent();
    	pt.setpId(1);
    	pt.setpName("Sudhir");
    	
    	Child ch1=new Child();
    	ch1.setcId(1);
    	ch1.setcName("Vrutvik");
    	ch1.setParent(pt);
    	
    	Child ch2=new Child();
       	ch2.setcId(2);
    	ch2.setcName("Krushna");
    	ch2.setParent(pt);
    	
    	session.save(ch1);
    	session.save(ch2);
    	
       	ArrayList list = new ArrayList();
    	list.add(ch1);
    	list.add(ch2);
    	pt.setChild(list);
    	
    	session.save(pt);
    	    	
    	tr.commit();
    	session.close();
    	System.out.println("Parent Love Child");
    }
}
